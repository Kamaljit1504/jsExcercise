
var guess=Math.floor((Math.random() * 20) + 1);
pas();

function pas()
{
  var g =prompt("Make a guess");

  if(g == guess)
  {

  alert("Guessed");
}
  else
    {

    alert("TRy Again b/w 1 & 20 \n ANS="+guess);

  // pas1();
    }
}
// function pas1()
// {
//   var g =prompt("Make a guess");
//
//   if(g == guess)
//   {
//   alert("Guessed");
//   }
//   else
//     {
//       alert("TRy Again **************************************************************** 1 & 5");
//   pas();
//     }
// }
