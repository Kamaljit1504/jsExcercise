var age =prompt("entre you age");
if(age % Math.sqrt(age) == 0)
{
  console.log("perfect squre");
  alert("perfect squre");
}
else
  {
  console.log(" not a perfect squre");
    alert("not perfect squre");
  }
