myFun();

function myFun() {
  var table = document.getElementById("myTable");
  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  str=prompt("Enter Name");
  str1=prompt("Enter  cell no");
  cell1.innerHTML = str;
  cell2.innerHTML = str1;
}
