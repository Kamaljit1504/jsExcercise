var n=prompt("enter a num");
var f=1;
for(i=n;i>0;i--)
{
  f=f*i;

}
alert(f);
